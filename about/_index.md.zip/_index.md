+++
title = "About Dale Hassinger"
date = "2020-04-19"
+++

### Lead Systems Engineer, SME, vExpert 2020
#### If you can script it, You can Automate it...

**![](/images/vexpert-2020.png)**

Email: Dale.Hassinger@vCrocs.info

Sharing content for the following Products:

* [VMware](https://www.vmware.com)
* [PowerShell](https://docs.microsoft.com/en-us/powershell/)
* [PowerCLI](https://www.vmware.com/support/developer/PowerCLI/)
* [vRealize Automation](https://www.vmware.com/products/vrealize-automation.html)
* [vRealize Operations](https://www.vmware.com/products/vrealize-operations.html)
* [vRealize Log Insight](https://www.vmware.com/products/vrealize-log-insight.html)

I have learned a lot from the vCommunity, Powershell and PowerCLI web sites.
I want to use this blog as a way for me to give back.
If one person finds anything I post helpful I will consider my efforts successful.
The code shared I use with vRealize Automation BluePrints and everyday VMware Admin functions.
Everyday I learn something new. If I think it should be shared I will write a blog about it. Check back often to see what I am doing next.

I like to wear Crocs and I like VMware Products. So what better name than "vCrocs"...

Thanks for visiting!

#### "9 - 5 pays the bills, 5 - 10 advances your career"

